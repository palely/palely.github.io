# -*- coding:utf-8 -*- 

import jinja2
from os import path

class Cache(jinja2.BytecodeCache):

    def __init__(self, directory):
        self.directory = directory

    def load_bytecode(self, bucket):
        filename = path.join(self.directory, bucket.key)
        if path.exists(filename):
            with open(filename, 'rb') as f:
                bucket.load_bytecode(f)
    
    def dump_bytecode(self, bucket):
        filename = path.join(self.directory, bucket.key)
        with open(filename, 'wb') as f:
            bucket.write_bytecode(f)
		

#创建字节码缓存
cache = Cache('./caches')

#创建环境
env = jinja2.Environment(trim_blocks = True, loader = jinja2.FileSystemLoader('./templates'), bytecode_cache = cache)

#加载模板
template = env.get_template('access.txt')

#渲染模板
print template.render(where = 'World')

input('')